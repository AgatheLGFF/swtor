import styles from "./Header.module.css";

function Header() {
  return (
    <header className={styles.header}>
      <nav className={styles.nav}>
        <a href="/" className={styles.logo}>
          <img src="https://picsum.photos/100/100" alt="Star Wars Explorer" />
          <span>Star Wars Explorer</span>
        </a>

        <ul>
          <li>
            <a href="/" className={styles.navlink}>
              Accueil
            </a>
          </li>
          <li>
            <a href="/" className={styles.navlink}>
              Films
            </a>
          </li>
          <li>
            <a href="/" className={styles.navlink}>
              Personnages
            </a>
          </li>
          <li>
            <a href="/" className={styles.navlink}>
              Planètes
            </a>
          </li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
