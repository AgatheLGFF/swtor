import MovieCard from "../components/cards/MovieCard";
import styles from "./pages.module.css";

function MoviesList() {
  const movies = [
    {
      id: "1",
      title: "Film 1",
      episode: 1,
    },
    {
      id: "2",
      title: "Film 2",
      episode: 2,
    },
    {
      id: "3",
      title: "Film 3",
      episode: 3,
    },
    {
      id: "4",
      title: "Film 4",
      episode: 4,
    },
    {
      id: "5",
      title: "Film 5",
      episode: 5,
    },
    {
      id: "6",
      title: "Film 6",
      episode: 6,
    },
    {
      id: "7",
      title: "Film 7",
      episode: 7,
    },
    {
      id: "8",
      title: "Film 8",
      episode: 8,
    },
    {
      id: "9",
      title: "Film 9",
      episode: 9,
    },
  ];

  return (
    <main>
      <h1>Liste des films</h1>

      <ul className={styles.grid}>
        {movies.map((movie) => (
          <li key={movie.id}>
            <a href={`/movies/${movie.id}`}>
              <MovieCard title={movie.title} episode={movie.episode} />
            </a>
          </li>
        ))}
      </ul>
    </main>
  );
}

export default MoviesList;
