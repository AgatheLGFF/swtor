import Header from "./components/Header";
import CharactersList from "./pages/CharactersList";
import Homepage from "./pages/Homepage";
import MoviesList from "./pages/MoviesList";
import PlanetsList from "./pages/PlanetsList";

type Page = "homepage" | "movies" | "planets" | "characters";

function App() {
  // ? Temporaire en attendant React Router
  const currentPage: Page = "homepage";

  return (
    <>
      <Header />

      {currentPage === "homepage" && <Homepage />}
      {currentPage === "movies" && <MoviesList />}
      {currentPage === "planets" && <PlanetsList />}
      {currentPage === "characters" && <CharactersList />}
    </>
  );
}

export default App;
